package a_doesItWork;

public class CeckForWorking {

	public static void main(String[] args) {
		System.out.println("yesssss, it wooooorks");
	}

}
